package com.nycto.newavatarbook;

import java.io.Serializable;

public class Avatar implements Serializable {

    private String name;
    private String element;
    private int age;
    private int imageId;

    public Avatar(String name, String element, int age, int imageId) {
        this.name = name;
        this.element = element;
        this.age = age;
        this.imageId = imageId;
    }

    public String getName() {
        return name;
    }

    public String getElement() {
        return element;
    }

    public int getAge() {
        return age;
    }

    public int getImageId() {
        return imageId;
    }
}
