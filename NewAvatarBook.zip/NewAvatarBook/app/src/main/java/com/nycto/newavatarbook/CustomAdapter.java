package com.nycto.newavatarbook;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class CustomAdapter extends ArrayAdapter<Avatar> {

    private ArrayList<Avatar> avatars;
    private Activity context;
    public CustomAdapter(ArrayList<Avatar> avatars, Activity context){
        super(context,R.layout.custom_view,avatars);
        this.avatars=avatars;
        this.context=context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = context.getLayoutInflater();
        View customView=layoutInflater.inflate(R.layout.custom_view,null,true);

        TextView menuName = customView.findViewById(R.id.customTextView);
        menuName.setText(avatars.get(position).getName());

        return customView;

    }
}
