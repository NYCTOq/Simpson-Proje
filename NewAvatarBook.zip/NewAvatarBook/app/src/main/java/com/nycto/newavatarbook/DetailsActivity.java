package com.nycto.newavatarbook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        ImageView imageView=findViewById(R.id.imageView);
        TextView nameText=findViewById(R.id.nameText);
        TextView ageText=findViewById(R.id.ageText);
        TextView elementText=findViewById(R.id.elementText);

        Intent intent=getIntent();
        Avatar selectedAvatar=(Avatar) intent.getSerializableExtra("selectedAvatar");


        Bitmap bitmap = BitmapFactory.decodeResource(getApplicationContext().getResources(),selectedAvatar.getImageId());
        imageView.setImageBitmap(bitmap);

        nameText.setText(selectedAvatar.getName());
        elementText.setText(selectedAvatar.getElement());
        ageText.setText(selectedAvatar.getAge());




    }
}