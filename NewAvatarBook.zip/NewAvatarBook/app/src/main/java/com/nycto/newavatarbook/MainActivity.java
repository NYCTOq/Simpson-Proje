package com.nycto.newavatarbook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listView=findViewById(R.id.listView);
        Avatar aang=new Avatar("aang","air",14,R.drawable.gorsel4);
        Avatar soka=new Avatar("sokka","warior",19,R.drawable.gorsel5);
        Avatar zuko=new Avatar("zuko","fire",19,R.drawable.gorsel6);
        Avatar katara=new Avatar("katara","water",16,R.drawable.gorsel7);

        final ArrayList<Avatar> avatarList = new ArrayList<>();
        avatarList.add(aang);
        avatarList.add(soka);
        avatarList.add(zuko);
        avatarList.add(katara);

        CustomAdapter customAdapter=new CustomAdapter(avatarList,MainActivity.this);
        listView.setAdapter(customAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent=new Intent(MainActivity.this,DetailsActivity.class);
                intent.putExtra("selectedAvatar",avatarList.get(position));
                startActivity(intent);

            }
        });
    }
}